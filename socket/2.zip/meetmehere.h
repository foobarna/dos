#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>

#define PORT 33344
#define IP "127.0.0.1"
#define MAX 100

struct triplet {
	int a,b,c;
};

struct largest {
	int sum;
	int ip;
	int port;
};