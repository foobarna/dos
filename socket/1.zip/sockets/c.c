#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
struct triple{
	int n1;
	int n2;
	int n3;
};
struct max{
       int sum;
       int ip;
       int port;
};

int main(){
	int sock, k;
	struct triple t;
        struct max m;
	struct sockaddr_in saddr;
	sock=socket(AF_INET, SOCK_STREAM, 0);
	memset(&saddr,0,sizeof(saddr));
        saddr.sin_family=AF_INET;
	saddr.sin_addr.s_addr=inet_addr("127.0.0.1");
	saddr.sin_port=htons(12345);
	connect(sock,(struct sockaddr *)&saddr, sizeof(saddr));
	//scanf("%d",&t.n1);
	//scanf("%d",&t.n2);
        //scanf("%d",&t.n3);
	srand(t.n1);
        t.n1=rand()%100;
	srand(t.n2+t.n1);
        t.n2=rand()%100;
        srand(rand()+t.n2);
        t.n3=rand()%100; 
        t.n1=htonl(t.n1);
        t.n2=htonl(t.n2);
        t.n3=htonl(t.n3);
        send(sock, &t, sizeof(struct triple),0);
        recv(sock,&m,sizeof(struct max),0);
	m.sum=ntohl(m.sum);
        //m.ip=ntohl(m.ip);
        m.port=ntohs(m.port);
	printf("%d %d\n",m.sum,m.port);
	close(sock);	
        return 0;
}
