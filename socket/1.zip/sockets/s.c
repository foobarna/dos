#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>

struct triple{
      int n1;
      int n2;
      int n3;
};
struct max{
	int sum;
	int ip;
	int port;
};
struct arg{
	int sock;
	int index;
};
struct max m;
struct sockaddr_in saddr;
pthread_t ths[100];
pthread_mutex_t mtx= PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t summtx=PTHREAD_MUTEX_INITIALIZER;

int findFreeThread() {
  int i;

  pthread_mutex_lock(&mtx);
  for(i=0; i<100; i++) {
    if(ths[i] == NULL) {
      pthread_mutex_unlock(&mtx);
      return i;
    }
  }
  pthread_mutex_unlock(&mtx);

  return -1;
}

void threads(struct arg* a){
	struct triple t;
        int k;
        
        recv(a->sock, &t, sizeof(struct triple),0);
        t.n1=ntohl(t.n1);
        t.n2=ntohl(t.n2);
        t.n3=ntohl(t.n3);
        printf("%d %d %d \n",t.n1,t.n2,t.n3);
        k=t.n1+t.n2+t.n3;
        pthread_mutex_lock(&summtx);
        if (k>m.sum){
               m.sum=k;
               m.port=saddr.sin_port;
               //m.ip = inet_aton(saddr.sin_addr);
         }
         pthread_mutex_unlock(&summtx);
         m.sum=htonl(m.sum);
         //m.ip=htonl(m.ip);
         //m.port=htonl(m.port);
         send(a->sock, &m, sizeof(struct max),0);
         m.sum=ntohl(m.sum);
         close(a->sock);
	 ths[a->index]=NULL;
	 free(a);
}

int main(){
	int rv,sock,i;
        unsigned int len;
        m.sum=0;
	m.port=0;
        i=0;
	rv=socket(AF_INET, SOCK_STREAM, 0);
	memset(&saddr,0,sizeof(saddr));
  saddr.sin_family=AF_INET;
	saddr.sin_addr.s_addr=INADDR_ANY;
	saddr.sin_port=htons(12345);
	bind(rv,(struct sockaddr *)&saddr, sizeof(saddr));
	listen(rv,6);
        len=sizeof(saddr);
        
        while(i<100){
        	ths[i]=NULL;
		i++;
        }        
	
	while(1){
        	sock=accept(rv,(struct sockaddr*)&saddr,&len);
                printf("SERVER: Connection from %s:%d\n", inet_ntoa(saddr.sin_addr), ntohs(saddr.sin_port));
		struct arg *a;
		a = (struct arg*)malloc(sizeof(struct arg));
		a->sock=sock;
		a->index=findFreeThread();
		pthread_create(&ths[a->index],NULL,(void*)threads,a);
	
	}	
        return 0;
}
